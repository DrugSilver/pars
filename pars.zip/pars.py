import json
import boto3
from boto3.dynamodb.conditions import Key, Attr
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('sudpovestki')


def main_handler(event, context):
    nm = event["nm"]
    
    response = table.scan(
        FilterExpression=Attr('ndeal').eq(nm)
    )
    
    items = response['Items']
    
    return {
        "statusCode": 200,
		"message" : "here you are again",
        "body": json.dumps(items)
    }